<?php
session_start();
$conexao = mysqli_connect('localhost', 'root', '', 'banco_sistema_financeiro');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: tela_login.html');
    exit;
}

$acao = $_POST['acao'];

if ($acao === 'login') {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $busca = mysqli_query($conexao, "SELECT * FROM usuarios WHERE email='$email' AND senha='$senha'");
    $contagem = mysqli_num_rows($busca);
    
    if ($contagem == 1) {
        $usuario = mysqli_fetch_assoc($busca);
        $_SESSION['logado'] = 1;
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['nome'] = $usuario['nome'];
        header('Location: tela_principal.php');
    } else {
        $_SESSION['logado'] = 0;
        header('Location: tela_login.html');
    }
    exit;
}

if ($acao === 'cadastrar') {
    $nome = $_POST['nome'];
    $idade = $_POST['idade'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    
    $busca = mysqli_query($conexao, "SELECT * FROM usuarios WHERE email='$email'");
    $contagem = mysqli_num_rows($busca);
    
    if ($contagem == 0) {
        $insercao = mysqli_query($conexao, "CALL inserir_usuarios('$nome', $idade, '$email', '$senha')");
        if ($insercao) {
            $_SESSION['logado'] = 1;
            header('Location: tela_login.html');
        } else {
            $_SESSION['logado'] = 0;
            header('Location: tela_cadastro.html');
        }
    } else {
        $_SESSION['logado'] = 0;
        header('Location: tela_cadastro.html');
    }
    exit;
}

if ($acao === 'adicionar' || $acao === 'editar' || $acao === 'excluir') {
    if ($_SESSION['logado'] != 1) {
        header('Location: tela_login.html');
        exit;
    }
    $usuario_id = $_SESSION['usuario_id'];

    if ($acao === 'adicionar') {
        $descricao = $_POST['descricao'];
        $valor = $_POST['valor'];
        $tipo = $_POST['tipo'];
        mysqli_query($conexao, "CALL inserir_transacoes($usuario_id, '$descricao', $valor, '$tipo')");
    }

    if ($acao === 'editar') {
        $id = $_POST['id'];
        $descricao = $_POST['descricao'];
        $valor = $_POST['valor'];
        $tipo = $_POST['tipo'];
        $id = (int)$id;
        mysqli_query($conexao, "CALL alterar_transacoes($id, $usuario_id, '$descricao', $valor, '$tipo')");
    }

    if ($acao === 'excluir') {
        $id = $_POST['id'];
        $id = (int)$id;
        mysqli_query($conexao, "CALL deletar_transacoes($id, $usuario_id)");
    }

    header('Location: tela_principal.php');
    exit;
}

header('Location: tela_login.html');
exit;
?>