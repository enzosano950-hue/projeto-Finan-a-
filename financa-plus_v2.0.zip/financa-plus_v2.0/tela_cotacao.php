<?php
session_start();
if (!isset($_SESSION['logado']) || $_SESSION['logado'] != 1) {
    header('Location: tela_login.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cotações - Finança+</title>
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/ferramentas.css">
    <link rel="stylesheet" href="css/cotacao.css">
   
</head>
<body>
    <header class="cabecalho">
        <a class="marca" href="index.php">Finança+</a>
        <nav class="menu">
            <a class="item-menu" href="index.php">Início</a>
            <a class="item-menu" href="tela_principal.php">Painel</a>
            <a class="item-menu" href="tela_conversor.php">Conversor</a>
            <a class="item-menu ativo" href="tela_cotacao.php">Cotações</a>
            <a class="item-menu" href="tela_previsao.php">Investimentos</a>
            <a class="item-menu" href="logout.php">Sair</a>
        </nav>
    </header>

    <main class="painel pagina-ferramenta">
        <div class="pagina-cabecalho">
            <div>
                <span class="tag">mercado de moedas</span>
                <h1>Cotação de Moedas</h1>
                <p>Descubra quanto uma moeda vale em relação a outra.</p>
            </div>
        </div>

        <section class="cartao-autenticacao cartao-ferramenta">
            <div class="grade-ferramenta dois">
                <div class="grupo-formulario">
                    <label for="moeda-cotacao-origem">Moeda base</label>
                    <select id="moeda-cotacao-origem"></select>
                </div>

                <div class="grupo-formulario">
                    <label for="moeda-cotacao-destino">Moeda desejada</label>
                    <select id="moeda-cotacao-destino"></select>
                </div>
            </div>

            <button id="consultar-cotacao" class="btn-enviar">Consultar cotação</button>

            <div class="painel-cotacao oculto" id="painel-cotacao">
                <span id="titulo-cotacao">1 BRL em USD</span>
                <strong id="valor-cotacao">--</strong>
                <p id="data-cotacao"> </p>
            </div>

            <p class="mensagem-erro" id="erro-cotacao"></p>
        </section>

        <section class="grade-informacoes">
            <div class="cartao-informacao">
                <h3>O que é a cotação?</h3>
                <p>É a relação de valor entre duas moedas. Por exemplo, se a cotação for de 5,00 significa que uma unidade da moeda base corresponde a 5 unidades da moeda desejada.</p>
            </div>

            <div class="cartao-informacao">
                <h3>Fonte dos dados</h3>
                <p>Os dados das moedas são consultados pela API Frankfurter,por isso podem ser diferentes das taxas usadas por bancos.</p>
            </div>
        </section>
    </main>

    <footer class="rodape">
        <p>© 2026 Finança+. Todos os direitos reservados.</p>
    </footer>

    <script src="js/moedas.js"></script>
    <script src="js/cotacao.js"></script>
</body>
</html>
