<?php
session_start();
if (!isset($_SESSION['logado']) || $_SESSION['logado'] != 1) {
    header('Location: tela_login.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conversor - Finança+</title>
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/ferramentas.css">
    <link rel="stylesheet" href="css/conversor.css">
  
</head>
<body>
    <header class="cabecalho">
        <a class="marca" href="index.php">Finança+</a>
        <nav class="menu">
            <a class="item-menu" href="index.php">Início</a>
            <a class="item-menu" href="tela_principal.php">Painel</a>
            <a class="item-menu ativo" href="tela_conversor.php">Conversor</a>
            <a class="item-menu" href="tela_cotacao.php">Cotações</a>
            <a class="item-menu" href="tela_previsao.php">Investimentos</a>
            <a class="item-menu" href="logout.php">Sair</a>
        </nav>
    </header>

    <main class="painel pagina-ferramenta">
        <div class="pagina-cabecalho">
            <div>
                <span class="tag">ferramenta para conversão de moedas</span>
                <h1>Conversor de Moedas</h1>
                <p>Converta valores entre moedas com uma cotação atualizada pela API.</p>
            </div>
        </div>

        <section class="cartao-autenticacao cartao-ferramenta">
            <form id="formulario-conversor" class="grade-ferramenta">
                <div class="grupo-formulario">
                    <label for="valor-conversao">Valor</label>
                    <input id="valor-conversao" type="number" min="0.01" step="0.01" value="100" required>
                </div>

                <div class="grupo-formulario">
                    <label for="origem">Moeda de origem</label>
                    <select id="origem"></select>
                </div>

                <button type="button" id="inverter" class="btn-inverter grande">↔</button>

                <div class="grupo-formulario">
                    <label for="destino">Moeda de destino</label>
                    <select id="destino"></select>
                </div>

                <button class="btn-enviar" type="submit">Converter</button>
            </form>

            <div class="resultado-destaque oculto" id="painel-resultado">
                <span>Resultado</span>
                <strong id="resultado">--</strong>
                <p id="linha-cotacao">Informe as moedas para consultar.</p>
                <small id="data"> </small>
            </div>

            <p class="mensagem-erro" id="erro"></p>
        </section>
    </main>

    <footer class="rodape">
        <p>© 2026 Finança+. Todos os direitos reservados.</p>
    </footer>

    <script src="js/moedas.js"></script>
    <script src="js/conversor.js"></script>
</body>
</html>
