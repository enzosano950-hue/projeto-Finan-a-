<?php
session_start();
if (!isset($_SESSION['logado']) || $_SESSION['logado'] != 1) {
    header('Location: tela_login.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Previsão de Investimentos - Finança+</title>
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/ferramentas.css">
    <link rel="stylesheet" href="css/previsao.css">
</head>
<body>
    <header class="cabecalho">
        <a class="marca" href="index.php">Finança+</a>
        <nav class="menu">
            <a class="item-menu" href="index.php">Início</a>
            <a class="item-menu" href="tela_principal.php">Painel</a>
            <a class="item-menu" href="tela_conversor.php">Conversor</a>
            <a class="item-menu" href="tela_cotacao.php">Cotações</a>
            <a class="item-menu ativo" href="tela_previsao.php">Investimentos</a>
            <a class="item-menu" href="logout.php">Sair</a>
        </nav>
    </header>

    <main class="painel pagina-ferramenta">
        <div class="pagina-cabecalho">
            <div>
                <span class="tag">planejamento</span>
                <h1>Previsão de Investimentos</h1>
                <p>Faça uma simulação de crescimento do seu dinheiro com aportes mensais.</p>
            </div>
        </div>

        <section class="cartao-autenticacao cartao-ferramenta">
            <form id="formulario-previsao" class="grade-ferramenta dois">
                <div class="grupo-formulario">
                    <label for="inicial">Investimento inicial (R$)</label>
                    <input id="inicial" type="number" min="0" step="0.01" value="1000" required>
                </div>

                <div class="grupo-formulario">
                    <label for="aporte">Aporte mensal (R$)</label>
                    <input id="aporte" type="number" min="0" step="0.01" value="300" required>
                </div>

                <div class="grupo-formulario">
                    <label for="taxa">Taxa anual estimada (%)</label>
                    <input id="taxa" type="number" min="0" step="0.01" value="10" required>
                </div>

                <div class="grupo-formulario">
                    <label for="prazo">Prazo (anos)</label>
                    <input id="prazo" type="number" min="1" max="100" step="1" value="5" required>
                </div>

                <button class="btn-enviar campo-completo" type="submit">Calcular previsão</button>
            </form>

            <div class="resultado-investimento oculto" id="painel-investimento">
                <div>
                    <span>Valor final estimado</span>
                    <strong id="valor-final">R$ 0,00</strong>
                </div>
                <div>
                    <span>Total investido</span>
                    <strong id="total-investido">R$ 0,00</strong>
                </div>
                <div>
                    <span>Rendimento estimado</span>
                    <strong id="rendimento" class="positivo">R$ 0,00</strong>
                </div>
            </div>

            <p class="aviso">Esta é uma simulação baseada nos valores informados. não nos responsabilisamos por perdas financeiras.</p>
        </section>
    </main>

    <footer class="rodape">
        <p>© 2026 Finança+. Todos os direitos reservados.</p>
    </footer>

    <script src="js/previsao.js"></script>
</body>
</html>
