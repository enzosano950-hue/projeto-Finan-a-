document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('formulario-previsao');

    function calcular() {
        document.getElementById('painel-investimento').classList.remove('oculto');

        const inicial = Number(document.getElementById('inicial').value) || 0;
        const aporte = Number(document.getElementById('aporte').value) || 0;
        const taxa = Number(document.getElementById('taxa').value) || 0;
        const prazo = Number(document.getElementById('prazo').value) || 0;

        const meses = prazo * 12;
        const juros = Math.pow(1 + taxa / 100, 1 / 12) - 1;

        let saldo = inicial;
        for (let i = 0; i < meses; i++) {
            saldo = saldo * (1 + juros) + aporte;
        }

        const investido = inicial + aporte * meses;

        document.getElementById('valor-final').textContent = formatarReal(saldo);
        document.getElementById('total-investido').textContent = formatarReal(investido);
        document.getElementById('rendimento').textContent = formatarReal(Math.max(0, saldo - investido));
    }

    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            calcular();
        });
    }
});

function formatarReal(valor) {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(valor);
}
