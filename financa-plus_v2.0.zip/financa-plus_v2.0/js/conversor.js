document.addEventListener('DOMContentLoaded', async () => {
    const origem = document.getElementById('origem');
    const destino = document.getElementById('destino');
    const valor = document.getElementById('valor-conversao');

    const painel = document.getElementById('painel-resultado');
    const resultado = document.getElementById('resultado');
    const linha = document.getElementById('linha-cotacao');
    const data = document.getElementById('data');
    const erro = document.getElementById('erro');

    await carregarMoedas([origem, destino]);
    origem.value = 'BRL';
    destino.value = 'USD';

    async function converter() {
        erro.textContent = '';
        painel.classList.remove('oculto');

        try {
            const numero = Number(valor.value);
            if (!numero || numero <= 0) throw new Error('Digite um valor maior que zero.');

            const dados = await obterCotacao(origem.value, destino.value);
            resultado.textContent = formatarMoeda(numero * dados.rate, destino.value);
            linha.textContent = `1 ${origem.value} = ${dados.rate.toLocaleString('pt-BR', { maximumFractionDigits: 8 })} ${destino.value}`;
            data.textContent = `Cotação de ${formatarData(dados.date)}`;
        } catch (e) {
            resultado.textContent = '--';
            linha.textContent = 'Não foi possível ver a cotação.';
            data.textContent = '';
            erro.textContent = e.message;
        }
    }

    document.getElementById('formulario-conversor').addEventListener('submit', (e) => {
        e.preventDefault();
        converter();
    });

    document.getElementById('inverter').addEventListener('click', () => {
        const v = origem.value;
        origem.value = destino.value;
        destino.value = v;
    });
});
