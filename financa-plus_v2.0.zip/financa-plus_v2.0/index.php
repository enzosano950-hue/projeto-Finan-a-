<?php 
session_start(); 
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finança+|Controle seu dinheiro em um só lugar</title>

    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/inicio.css">
</head>
<body class="pagina-inicial">
<header class="cabecalho">
    <a class="marca" href="index.php">Finança+</a>
    <nav class="menu">
        <a class="item-menu ativo" aria-current="page" href="index.php">Início</a>
        <a class="item-menu" href="tela_principal.php">Painel</a>
        <a class="item-menu" href="tela_conversor.php">Conversor</a>
        <a class="item-menu" href="tela_cotacao.php">Cotações</a>
        <a class="item-menu" href="tela_previsao.php">Investimentos</a>
        <?php
        
        if (isset($_SESSION['logado']) && $_SESSION['logado'] == 1) { 
            ?>
            <a class="item-menu" href="logout.php">Sair</a>
        <?php 
        } else { 
            ?>
            <a class="item-menu" href="tela_login.html">Entrar</a>
            <a class="btn-menu" href="tela_cadastro.html">Criar conta</a>
        <?php }
         ?>
    </nav>
</header>

<main>
    <section class="inicio-hero">
        <div>
            <h1>seu dinheiro no melhor lugar.</h1>
            <p class="inicio-lead">O Finança+ tem tudo que você precisa para organizar seus gastos e investimentos: registre seus gastos mensais, confira a cotação de moedas e veja quanto seu dinheiro pode render.</p>
            <?php 
            if 
            (!isset($_SESSION['logado']) || $_SESSION['logado'] != 1) {
                 ?>
            <div class="inicio-acoes">
                <a class="btn-enviar" href="tela_cadastro.html">Criar minha conta</a>
                <a class="btn-enviar btn-secundario" href="tela_login.html">Já tenho conta</a>
            </div>
            <?php }
             ?>
        </div>

        <img src="imagens/images.jpg" class="inicio-imagem">

    <section class="inicio-secao" aria-labelledby="titulo-recursos">
        <h2 id="titulo-recursos">O que você encontra na finança+</h2>
        <p class="inicio-intro">Quatro ferramentas para usar no seu dia a dia.</p>
        <ul class="recursos">
            <li>
                <h3>Painel de gastos e ganhos</h3>
                <p>Registre o que vc ganha e gasta e acompanhe o saldo atualizado na hora. eles ficam salvos neste navegador.</p>
                <a href="tela_principal.php">Abrir o painel</a>
            </li>
            <li>
                <h3>Conversor de moedas</h3>
                <p>Converta um valor entre moedas como real, dólar e euro, usando a cotação da API Frankfurter.</p>
                <a href="tela_conversor.php">Converter valores</a>
            </li>
            <li>
                <h3>Cotações</h3>
                <p>Descubra quanto uma moeda vale em relação a outra, com a data da cotação consultada.</p>
                <a href="tela_cotacao.php">Ver cotações</a>
            </li>
            <li>
                <h3>Previsão de investimentos</h3>
                <p>Informe o valor inicial, o deposito mensal, a taxa de rendimento e o prazo para ver o total que investiu e o rendimento estimado.</p>
                <a href="tela_previsao.php">Simular investimento</a>
            </li>
        </ul>
    </section>

    <section class="inicio-secao" >
        <h2 id="titulo-passos">Como começar</h2>
        
        <ol class="passos">
            <li>
                <h3>Crie sua conta</h3>
                <p>Informe nome, idade e e-mail e defina uma senha. Depois é só entrar.</p>
            </li>
            <li>
                <h3>Registre suas transações</h3>
                <p>Lance seu salário, seus gastos mensais como a conta de luz,aluguel,etc..  O painel soma ganhos e gastos e mostra seu saldo.</p>
            </li>
            <li>
                <h3>Planeje o próximo passo</h3>
                <p>Compare moedas se for viajar, comprar fora ou investir em outra moeda, e simule quanto um investimento mensal pode render.</p>
            </li>
        </ol>
    </section>

    <?php 
   
   if 
    (!isset($_SESSION['logado']) || $_SESSION['logado'] != 1) {
         ?>
    <section class="inicio-secao">
        <div class="inicio-cta">
            <div>
                <h2>Comece criando sua conta</h2>
                <p>Crie sua conta e registre a primeira transação. As cotações e conversões são apenas dados coletados da API. elas não garantem nenhum ganho.</p>
            </div>
            <a class="btn-enviar" href="tela_cadastro.html">Criar minha conta</a>
        </div>
    </section>
    <?php }
     ?>
</main>

<footer class="rodape"><p>© 2026 Finança+. Todos os direitos reservados.</p></footer>

</body>
</html>
