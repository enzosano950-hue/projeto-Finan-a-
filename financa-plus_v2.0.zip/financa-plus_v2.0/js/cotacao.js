document.addEventListener('DOMContentLoaded', async () => {
    const painel = document.getElementById('painel-cotacao');
    const origem = document.getElementById('moeda-cotacao-origem');
    const destino = document.getElementById('moeda-cotacao-destino');
    const valorEl = document.getElementById('valor-cotacao');
    const tituloEl = document.getElementById('titulo-cotacao');
    const dataEl = document.getElementById('data-cotacao');
    const erroEl = document.getElementById('erro-cotacao');

    await carregarMoedas([origem, destino]);
    origem.value = 'USD';
    destino.value = 'BRL';

    async function consultar() {
        erroEl.textContent = '';
        painel.classList.remove('oculto');
        try {
            const x = await obterCotacao(origem.value, destino.value);
            valorEl.textContent = x.rate.toLocaleString('pt-BR', { maximumFractionDigits: 8 });
            tituloEl.textContent = `1 ${origem.value} = ${destino.value}`;
            dataEl.textContent = `Cotação de ${formatarData(x.date)}`;
        } catch (e) {
            valorEl.textContent = '--';
            dataEl.textContent = '';
            erroEl.textContent = e.message;
        }
    }

    document.getElementById('consultar-cotacao').addEventListener('click', consultar);
});
