<?php
session_start();
if (!isset($_SESSION['logado']) || $_SESSION['logado'] != 1) {
    header('Location: tela_login.html');
    exit;
}
$conexao = mysqli_connect('localhost', 'root', '', 'banco_sistema_financeiro');
$usuario_id = $_SESSION['usuario_id'];

$editando = null;
if (isset($_GET['editar'])) {
    $id_editar = $_GET['editar'];
    $res = mysqli_query($conexao, "SELECT * FROM transacoes WHERE id=$id_editar AND usuario_id=$usuario_id");
    $editando = mysqli_fetch_assoc($res);
}

$lista = mysqli_query($conexao, "SELECT * FROM transacoes WHERE usuario_id=$usuario_id");
$transacoes = [];
$entradas = 0;
$saidas = 0;
while ($linha = mysqli_fetch_assoc($lista)) {
    $transacoes[] = $linha;
    if ($linha['tipo'] == 'entrada') { $entradas += $linha['valor']; } else { $saidas += $linha['valor']; }
}
$total = $entradas - $saidas;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel - Finança+</title>
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/principal.css">
</head>
<body>
<header class="cabecalho">
    <a class="marca" href="index.php">Finança+</a>
    <nav class="menu">
        <a class="item-menu" href="index.php">Início</a>
        <a class="item-menu ativo"  href="tela_principal.php">Painel</a>
        <a class="item-menu" href="tela_conversor.php">Conversor</a>
        <a class="item-menu" href="tela_cotacao.php">Cotações</a>
        <a class="item-menu" href="tela_previsao.php">Investimentos</a>
        <span class="item-menu">Olá, <?php echo $_SESSION['nome']; 
        ?></span>
        <a class="item-menu" href="logout.php">Sair</a>
    </nav>
</header>
<main class="painel">
    <section class="cartoes-resumo">
        <div class="cartao-resumo">
            <h3>Ganhos</h3><p class="valor positivo">R$ <?php echo number_format($entradas, 2, ',', '.'); 
            ?></p>
        </div>
        <div class="cartao-resumo">
            <h3>gastos</h3><p class="valor negativo">R$ <?php echo number_format($saidas, 2, ',', '.'); 
            ?></p>
        </div>
        <div class="cartao-resumo">
            <h3>Saldo Total</h3><p class="valor <?php echo $total >= 0 ? 'positivo' : 'negativo'; 
            ?>">R$ <?php echo number_format($total, 2, ',', '.'); 
            ?></p>
        </div>
    </section>

    <section class="cartao-autenticacao largura-total">
        <h2>
            <?php echo $editando ? 'Editar Transação' : 'Nova Transação'; 
            ?></h2>
        <form id="formulario-transacao" class="formulario-transacao" method="POST" action="php.php">
            <input type="hidden" name="acao" value="<?php echo $editando ? 'editar' : 'adicionar'; 
            ?>">
            <?php
             if ($editando) { 
                ?>
                <input type="hidden" name="id" value="<?php echo $editando['id']; 
                ?>">
            <?php } 
            ?>
            <div class="grupo-formulario">
                <label for="descricao">Descrição</label>
                <input type="text" id="descricao" name="descricao" required placeholder="Ex: Salário, Mercado" value="<?php echo $editando ? $editando['descricao'] : ''; 
                ?>">
            </div>
            <div class="grupo-formulario">
                <label for="valor">Valor (R$)</label>
                <input type="number" step="0.01" min="0.01" id="valor" name="valor" required placeholder="0,00" value="<?php echo $editando ? $editando['valor'] : ''; 
                ?>">
            </div>
            <div class="grupo-formulario">
                <label for="tipo">Tipo</label>
                <select id="tipo" name="tipo">
                    <option value="entrada" <?php 
                    if ($editando && $editando['tipo'] == 'entrada') echo 'selected';
                     ?>>Entrada</option>
                    <option value="saida" <?php 
                    if ($editando && $editando['tipo'] == 'saida') echo 'selected'; 
                    ?>>Saída</option>
                </select>
            </div>
            <button type="submit" class="btn-enviar"><?php echo $editando ? 'Salvar' : 'Adicionar'; 
            ?></button>
        </form>
    </section>

    <section><table class="tabela-transacoes">
        <thead>
            <tr>
            <th>Descrição</th>
            <th>Valor</th>
            <th>Tipo</th>
            <th>Ação</th>
        </tr>
    </thead>
        <tbody id="lista-transacoes">
        <?php foreach ($transacoes as $t) { ?>
            <tr>
                <td>
                    <?php echo $t['descricao']; 
                ?></td>
                <td class="<?php echo $t['tipo'] == 'entrada' ? 'valor-entrada' : 'valor-saida'; 
                ?>">R$ <?php echo number_format($t['valor'], 2, ',', '.'); 
                ?></td>
                <td><?php echo $t['tipo'] == 'entrada' ? 'Entrada' : 'Saída'; 
                ?></td>
                <td>
                    <a class="btn-remover" href="tela_principal.php?editar=<?php echo $t['id']; 
                    ?>">Editar</a>
                    <form method="POST" action="php.php" style="display:inline">
                        <input type="hidden" name="acao" value="excluir">
                        <input type="hidden" name="id" value="<?php echo $t['id']; 
                        ?>">
                        <button type="submit" class="btn-remover">Remover</button>
                    </form>
                </td>
            </tr>
        <?php } 
        ?>
        </tbody>
    </table>
</section>
</main>
<footer class="rodape"><p>© 2026 Finança+. Todos os direitos reservados.</p></footer>
</body>
</html>
